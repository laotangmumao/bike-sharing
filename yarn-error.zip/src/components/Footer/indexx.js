import React, { Component } from 'react'
import './index.less'
export default class Footer extends Component {
    render() {
        return (
            <div className='footer'>
                版权所有：版权？版权？版权？么得版权，明天的你会感谢今天努力的自己
            </div>
        )
    }
}
