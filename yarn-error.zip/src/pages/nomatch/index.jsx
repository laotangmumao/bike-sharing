import React, { Component } from 'react'

export default class NoMatch extends Component {
    render() {
        return (
            <div style={{textAlign:'center',fontSize:"24px"}}>
                404 No Found!!!
            </div>
        )
    }
}
