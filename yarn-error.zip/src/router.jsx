import React, { Component } from 'react'
import { HashRouter , Route , Router , Switch } from 'react-router-dom'
import App from './App'
import Login from './pages/login'
import Admin from './admin'
import Buttons from './pages/ui/Buttons'
import NoMatch from './pages/nomatch'
import Modals from './pages/ui/Modals'
import Loading from './pages/ui/Loading'
import Notice from './pages/ui/Notice'
import Messages from './pages/ui/Messages'
import ITabs from './pages/ui/Tabs'
import Gallery from './pages/ui/Gallery'
import ICarousel from './pages/ui/Carousel'
import FormLogin from './pages/form/Login'
import FormRegister from './pages/form/Register'
import BasicTable from './pages/table/BasicTable'
import HighTable from './pages/table/HighTable'
import City from './pages/city'
import Order from './pages/order'
import Common from './Common'
import OrderDetail from './pages/order/detail'

export default class IRouter extends Component {
    render() {
        return (
            <div>
                <HashRouter>
                    <App>
                        <Route path='/login' component={Login} />
                        <Route path='/admin' render={()=>
                            <Admin>
                                <Switch>
                                    <Route  path='/admin/ui/buttons' component={Buttons} />
                                    <Route  path='/admin/ui/modals' component={Modals} />
                                    <Route  path='/admin/ui/loadings' component={Loading} />
                                    <Route path='/admin/ui/notification' component={Notice} />
                                    <Route path='/admin/ui/messages' component={Messages} />
                                    <Route path='/admin/ui/tabs' component={ITabs} />
                                    <Route path='/admin/ui/gallery' component={Gallery} />
                                    <Route path='/admin/ui/carousel' component={ICarousel} />
                                    <Route path='/admin/form/login' component={FormLogin} />
                                    <Route path='/admin/form/reg' component={FormRegister} />
                                    <Route path='/admin/table/basic' component={BasicTable} />
                                    <Route path='/admin/table/high' component={HighTable} />
                                    <Route path='/admin/city' component={City} />
                                    <Route path='/admin/order' component={Order} />
                                    <Route  component={NoMatch} />
                                </Switch>
                            </Admin>
                        } />
                        <Route path='/common' render={()=>
                            <Common>
                                <Route path='/common/order/detail/:orderId' component={OrderDetail} />
                            </Common>
                        }

                        />
                    </App>
                </HashRouter>
            </div>
        )
    }
}
